import React from 'react'
import banner from './banner-1.png';
import './banner.css';
export const Banner = () => {
    return (
        <div className='banner'>

        </div>
    );
}
