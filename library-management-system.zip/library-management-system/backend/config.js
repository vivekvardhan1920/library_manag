// export const PORT = 5555;
export const mongoDBURL =
    'mongodb+srv://root:root@cluster0.hfyfcwx.mongodb.net/?retryWrites=true&w=majority';